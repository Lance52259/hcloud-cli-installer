## OPEN SOURCE SOFTWARE NOTICE
Please note we provide an open source software notice along with this product and/or this product firmware (in the following just “this product”). The open source software licenses are granted by the respective right holders. And the open source licenses prevail all other license information with regard to the respective open source software contained in the product, including but not limited to End User Software Licensing Agreement. This notice is provided on behalf of Huawei Technologies Co. Ltd. and any of its local subsidiaries which may have provided this product to you in your local country.

### Warranty Disclaimer
THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.

### Copyright Notice and License Texts

**Software :** cloud.google.com/go/compute/metadata v0.3.0

**Copyright notice :** Copyright 2018 Google LLC
Copyright 2014 Google LLC
Copyright 2016 Google LLC
Copyright 2021 Google LLC
Copyright 2022 Google LLC

**License :** Apache License V2.0

Apache License  Version 2.0, January 2004  http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

     "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9 of this document.  
     "Licensor" shall mean the copyright owner or entity authorized by the copyright owner that is granting the License.  
     "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.  
     "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.  
     "Source" form shall mean the preferred form for making modifications, including but not limited to software source code, documentation source, and configuration files.  
     "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but not limited to compiled object code, generated documentation, and conversions to other media types.  
     "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).  
     "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from, or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.  
     "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives, including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work, but excluding communication that is conspicuously marked or otherwise designated in writing by the copyright owner as "Not a Contribution."  
     "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received by Licensor and subsequently incorporated within the Work.  

2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or Object form.
3. Grant of Patent License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) patent license to make, have made, use, offer to sell, sell, import, and otherwise transfer the Work, where such license applies only to those patent claims licensable by such Contributor that are necessarily infringed by their Contribution(s) alone or by combination of their Contribution(s) with the Work to which such Contribution(s) was submitted. If You institute patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Work or a Contribution incorporated within the Work constitutes direct or contributory patent infringement, then any patent licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.
4. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or without modifications, and in Source or Object form, provided that You meet the following conditions:

     (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and  
     (b) You must cause any modified files to carry prominent notices stating that You changed the files; and  
     (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative Works; and  
     (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or, within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that such additional attribution notices cannot be construed as modifying the License. You may add Your own copyright statement to Your modifications and may provide additional or different license terms and conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.  

5. Submission of Contributions. Unless You explicitly state otherwise, any Contribution intentionally submitted for inclusion in the Work by You to the Licensor shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor regarding such Contributions.
6. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing the content of the NOTICE file.
7. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing the Work and assume any risks associated with Your exercise of permissions under this License.
8. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses), even if such Contributor has been advised of the possibility of such damages.
9. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such warranty or additional liability.

END OF TERMS AND CONDITIONS
APPENDIX: How to apply the Apache License to your work.
To apply the Apache License to your work, attach the following boilerplate notice, with the fields enclosed by brackets "[]" replaced with your own identifying information. (Don't include the brackets!) The text should be enclosed in the appropriate comment syntax for the file format. We also recommend that a file or class name and description of purpose be included on the same "printed page" as the copyright notice for easier identification within third-party archives.
Copyright [yyyy] [name of copyright owner]
Licensed under the Apache License, Version 2.0 (the "License");  you may not use this file except in compliance with the License.  You may obtain a copy of the License at  
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software  distributed under the License is distributed on an "AS IS" BASIS,  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  See the License for the specific language governing permissions and  limitations under the License.

**Software :** github.com/AlecAivazis/survey/v2 v2.3.7

**Copyright notice :** Copyright (c) 2018 Alec Aivazis<br/>Copyright (c) 2014 Takashi Kokubun<br/>Copyright 2013 The Go Authors<br/>Copyright 2011 The Go Authors

**License :** MIT License

MIT License

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice (including the next paragraph) shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.



**Software :** github.com/Masterminds/semver/v3 v3.4.0

**Copyright notice :** Copyright (c) 2014-2019, Matt Butcher and Matt Farina

**License :** MIT License

Please see above.

**Software :** github.com/NYTimes/gziphandler v1.1.1

**Copyright notice :** Copyright 2016-2017 The New York Times Company

**License :** Apache License V2.0

Please see above.

**Software :** github.com/Netflix/go-expect v0.0.0-20220104043353-73e0943537d2

**Copyright notice :** Copyright 2018 Netflix, Inc.

**License :** Apache License V2.0

Please see above.

**Software :** github.com/VividCortex/ewma v1.2.0

**Copyright notice :** Copyright (c) 2013 VividCortex

**License :** MIT License

Please see above.

**Software :** github.com/agiledragon/gomonkey/v2 v2.13.0

**Copyright notice :** Copyright (c) 2018 Zhang Xiaolong
Copyright 2022 ByteDance Inc.

**License :** MIT License

Please see above.

**Software :** github.com/armon/go-socks5 v0.0.0-20160902184237-e75332964ef5

**Copyright notice :** Copyright (c) 2014 Armon Dadgar

**License :** MIT License

Please see above.

**Software :** github.com/cheggaaa/pb/v3 v3.1.4

**Copyright notice :** Copyright (c) 2012-2015, Sergey Cherepanov

**License :** BSD 3-Clause "New" or "Revised" License

Copyright (c) <year> <owner>.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

**Software :** github.com/clbanning/mxj/v2 v2.7.0

**Copyright notice :** Copyright 2012-2019, Charles Banning
Copyright 2016 Charles Banning
Copyright 2012-2014 Charles Banning
Copyright (c) 2012-2021 Charles Banning <clbanning@gmail.com>
Copyright 2012-2014, 2018 Charles Banning
Copyright 2012-2017 Charles Banning
Copyright 2012-2014, 2017 Charles Banning
Copyright 2012-2016, 2018-2019 Charles Banning
Copyright 2012-2016, 2019 Charles Banning
Copyright (c) 2012-2016 Charles Banning <clbanning@gmail.com>
Copyright 2012-2018 Charles Banning

**License :** MIT License

Please see above.

**Software :** github.com/cpuguy83/go-md2man/v2 v2.0.6

**Copyright notice :** Copyright (c) 2014 Brian Goff

**License :** MIT License

Please see above.

**Software :** github.com/creack/pty v1.1.17

**Copyright notice :** Copyright 2014 The Go Authors
Copyright (c) 2011 Keith Rarick

**License :** MIT License

Please see above.

**Software :** github.com/davecgh/go-spew v1.1.1

**Copyright notice :** Copyright (c) 2012-2016 Dave Collins <dave@davec.name>
Copyright (c) 2013-2016 Dave Collins <dave@davec.name>
Copyright (c) 2013 Dave Collins <dave@davec.name>
Copyright (c) 2015-2016 Dave Collins <dave@davec.name>

**License :** ISC License

ISC License

Copyright (c) 2004-2010 by Internet Systems Consortium, Inc. ("ISC")  Copyright (c) 1995-2003 by Internet Software Consortium

Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.
THE SOFTWARE IS PROVIDED "AS IS" AND ISC DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL ISC BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

**Software :** github.com/emicklei/go-restful/v3 v3.12.2

**Copyright notice :** Copyright 2013 Ernest Micklei
Copyright 2015 Ernest Micklei
(c) 2012-2015, http://ernestmicklei.com
Copyright 2021 Ernest Micklei
Copyright (c) 2012,2013 Ernest Micklei
Copyright 2014 Ernest Micklei
Copyright 2018 Ernest Micklei
(c) 2012 - 2023, http://ernestmicklei.com

**License :** MIT License

Please see above.

**Software :** github.com/emmansun/gmsm v0.41.1

**Copyright notice :** Copyright (c) 2020 Sun Yimin
Copyright 2024 Sun Yimin
Copyright 2025 Sun Yimin
Copyright 2021 The Go Authors
Copyright 2009 The Go Authors
Copyright 2013 The Go Authors
Copyright 2023 The Go Authors
Copyright 2024 The Go Authors
Copyright 2016 The Go Authors
Copyright 2018 The Go Authors
Copyright 2019 The Go Authors
Copyright 2025 The Go Authors
Copyright 2020 The Go Authors
Copyright 2022 The Go Authors
Copyright (c) 2015-2020 The fiat-crypto Authors
Copyright 2021 Sun Yimin
Copyright (c) 2009 The Go Authors
Copyright 2015 The Go Authors
Copyright (c) 2015 Andrew Smith
Copyright (c) 2014 youmark
Copyright 2026 The gmsm Authors
Copyright 2017 The Go Authors
Copyright 2012 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** github.com/emmansun/gmsm v0.41.1

**Copyright notice :** Copyright (c) 2020 Sun Yimin
Copyright 2024 Sun Yimin
Copyright 2025 Sun Yimin
Copyright 2021 The Go Authors
Copyright 2009 The Go Authors
Copyright 2013 The Go Authors
Copyright 2023 The Go Authors
Copyright 2024 The Go Authors
Copyright 2016 The Go Authors
Copyright 2018 The Go Authors
Copyright 2019 The Go Authors
Copyright 2025 The Go Authors
Copyright 2020 The Go Authors
Copyright 2022 The Go Authors
Copyright (c) 2015-2020 The fiat-crypto Authors
Copyright 2021 Sun Yimin
Copyright (c) 2009 The Go Authors
Copyright 2015 The Go Authors
Copyright (c) 2015 Andrew Smith
Copyright (c) 2014 youmark
Copyright 2026 The gmsm Authors
Copyright 2017 The Go Authors
Copyright 2012 The Go Authors

**License :** MIT License

Please see above.

**Software :** github.com/fatih/color v1.18.0

**Copyright notice :** Copyright (c) 2013 Fatih Arslan

**License :** MIT License

Please see above.

**Software :** github.com/fxamacker/cbor/v2 v2.9.0

**Copyright notice :** Copyright (c) Faye Amacker
Copyright (c) 2019-present Faye Amacker
Copyright (c) 2019-2024 Faye Amacker (https://github.com/fxamacker)
Copyright (c) 2004, 2006 The Linux Foundation and its contributors
Copyright 2020-2023 Montgomery Edwards448
Copyright (c) 2021-2023 Montgomery Edwards448

**License :** MIT License

Please see above.

**Software :** github.com/go-jose/go-jose/v3 v3.0.3

**Copyright notice :** Copyright 2014 Square Inc.
Copyright 2018 Square Inc.
Copyright 2011 The Go Authors
Copyright 2010 The Go Authors
Copyright (c) 2012 The Go Authors
Copyright 2016 Zbigniew Mandziejewicz
Copyright 2016 Square, Inc.
Copyright 2017 Square Inc.

**License :** Apache License V2.0

Please see above.

**Software :** github.com/go-logr/logr v1.4.3

**Copyright notice :** Apache License
Version 2.0, January 2004
http://www.apache.org/licenses/

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Definitions.

   "License" shall mean the terms and conditions for use, reproduction,
   and distribution as defined by Sections 1 through 9 of this document.

   "Licensor" shall mean the copyright owner or entity authorized by
   the copyright owner that is granting the License.

   "Legal Entity" shall mean the union of the acting entity and all
   other entities that control, are controlled by, or are under common
   control with that entity. For the purposes of this definition,
   "control" means (i) the power, direct or indirect, to cause the
   direction or management of such entity, whether by contract or
   otherwise, or (ii) ownership of fifty percent (50%) or more of the
   outstanding shares, or (iii) beneficial ownership of such entity.

   "You" (or "Your") shall mean an individual or Legal Entity
   exercising permissions granted by this License.

   "Source" form shall mean the preferred form for making modifications,
   including but not limited to software source code, documentation
   source, and configuration files.

   "Object" form shall mean any form resulting from mechanical
   transformation or translation of a Source form, including but
   not limited to compiled object code, generated documentation,
   and conversions to other media types.

   "Work" shall mean the work of authorship, whether in Source or
   Object form, made available under the License, as indicated by a
   copyright notice that is included in or attached to the work
   (an example is provided in the Appendix below).

   "Derivative Works" shall mean any work, whether in Source or Object
   form, that is based on (or derived from) the Work and for which the
   editorial revisions, annotations, elaborations, or other modifications
   represent, as a whole, an original work of authorship. For the purposes
   of this License, Derivative Works shall not include works that remain
   separable from, or merely link (or bind by name) to the interfaces of,
   the Work and Derivative Works thereof.

   "Contribution" shall mean any work of authorship, including
   the original version of the Work and any modifications or additions
   to that Work or Derivative Works thereof, that is intentionally
   submitted to Licensor for inclusion in the Work by the copyright owner
   or by an individual or Legal Entity authorized to submit on behalf of
   the copyright owner. For the purposes of this definition, "submitted"
   means any form of electronic, verbal, or written communication sent
   to the Licensor or its representatives, including but not limited to
   communication on electronic mailing lists, source code control systems,
   and issue tracking systems that are managed by, or on behalf of, the
   Licensor for the purpose of discussing and improving the Work, but
   excluding communication that is conspicuously marked or otherwise
   designated in writing by the copyright owner as "Not a Contribution."

   "Contributor" shall mean Licensor and any individual or Legal Entity
   on behalf of whom a Contribution has been received by Licensor and
   subsequently incorporated within the Work.

2. Grant of Copyright License. Subject to the terms and conditions of
   this License, each Contributor hereby grants to You a perpetual,
   worldwide, non-exclusive, no-charge, royalty-free, irrevocable
   copyright license to reproduce, prepare Derivative Works of,
   publicly display, publicly perform, sublicense, and distribute the
   Work and such Derivative Works in Source or Object form.

3. Grant of Patent License. Subject to the terms and conditions of
   this License, each Contributor hereby grants to You a perpetual,
   worldwide, non-exclusive, no-charge, royalty-free, irrevocable
   (except as stated in this section) patent license to make, have made,
   use, offer to sell, sell, import, and otherwise transfer the Work,
   where such license applies only to those patent claims licensable
   by such Contributor that are necessarily infringed by their
   Contribution(s) alone or by combination of their Contribution(s)
   with the Work to which such Contribution(s) was submitted. If You
   institute patent litigation against any entity (including a
   cross-claim or counterclaim in a lawsuit) alleging that the Work
   or a Contribution incorporated within the Work constitutes direct
   or contributory patent infringement, then any patent licenses
   granted to You under this License for that Work shall terminate
   as of the date such litigation is filed.

4. Redistribution. You may reproduce and distribute copies of the
   Work or Derivative Works thereof in any medium, with or without
   modifications, and in Source or Object form, provided that You
   meet the following conditions:

   (a) You must give any other recipients of the Work or
   Derivative Works a copy of this License; and

   (b) You must cause any modified files to carry prominent notices
   stating that You changed the files; and

   (c) You must retain, in the Source form of any Derivative Works
   that You distribute, all copyright, patent, trademark, and
   attribution notices from the Source form of the Work,
   excluding those notices that do not pertain to any part of
   the Derivative Works; and

   (d) If the Work includes a "NOTICE" text file as part of its
   distribution, then any Derivative Works that You distribute must
   include a readable copy of the attribution notices contained
   within such NOTICE file, excluding those notices that do not
   pertain to any part of the Derivative Works, in at least one
   of the following places: within a NOTICE text file distributed
   as part of the Derivative Works; within the Source form or
   documentation, if provided along with the Derivative Works; or,
   within a display generated by the Derivative Works, if and
   wherever such third-party notices normally appear. The contents
   of the NOTICE file are for informational purposes only and
   do not modify the License. You may add Your own attribution
   notices within Derivative Works that You distribute, alongside
   or as an addendum to the NOTICE text from the Work, provided
   that such additional attribution notices cannot be construed
   as modifying the License.

   You may add Your own copyright statement to Your modifications and
   may provide additional or different license terms and conditions
   for use, reproduction, or distribution of Your modifications, or
   for any such Derivative Works as a whole, provided Your use,
   reproduction, and distribution of the Work otherwise complies with
   the conditions stated in this License.

5. Submission of Contributions. Unless You explicitly state otherwise,
   any Contribution intentionally submitted for inclusion in the Work
   by You to the Licensor shall be under the terms and conditions of
   this License, without any additional terms or conditions.
   Notwithstanding the above, nothing herein shall supersede or modify
   the terms of any separate license agreement you may have executed
   with Licensor regarding such Contributions.

6. Trademarks. This License does not grant permission to use the trade
   names, trademarks, service marks, or product names of the Licensor,
   except as required for reasonable and customary use in describing the
   origin of the Work and reproducing the content of the NOTICE file.

7. Disclaimer of Warranty. Unless required by applicable law or
   agreed to in writing, Licensor provides the Work (and each
   Contributor provides its Contributions) on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
   implied, including, without limitation, any warranties or conditions
   of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
   PARTICULAR PURPOSE. You are solely responsible for determining the
   appropriateness of using or redistributing the Work and assume any
   risks associated with Your exercise of permissions under this License.

8. Limitation of Liability. In no event and under no legal theory,
   whether in tort (including negligence), contract, or otherwise,
   unless required by applicable law (such as deliberate and grossly
   negligent acts) or agreed to in writing, shall any Contributor be
   liable to You for damages, including any direct, indirect, special,
   incidental, or consequential damages of any character arising as a
   result of this License or out of the use or inability to use the
   Work (including but not limited to damages for loss of goodwill,
   work stoppage, computer failure or malfunction, or any and all
   other commercial damages or losses), even if such Contributor
   has been advised of the possibility of such damages.

9. Accepting Warranty or Additional Liability. While redistributing
   the Work or Derivative Works thereof, You may choose to offer,
   and charge a fee for, acceptance of support, warranty, indemnity,
   or other liability obligations and/or rights consistent with this
   License. However, in accepting such obligations, You may act only
   on Your own behalf and on Your sole responsibility, not on behalf
   of any other Contributor, and only if You agree to indemnify,
   defend, and hold each Contributor harmless for any liability
   incurred by, or claims asserted against, such Contributor by reason
   of your accepting any such warranty or additional liability.

END OF TERMS AND CONDITIONS

APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "{}"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

Copyright {yyyy} {name of copyright owner}

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

**License :** Apache License V2.0

Please see above.

**Software :** github.com/go-openapi/jsonpointer v0.21.0

**Copyright notice :** Copyright 2013 sigu-399 https://github.com/sigu-399
Copyright (c) 2004, 2006 The Linux Foundation and its contributors

**License :** Apache License V2.0

Please see above.

**Software :** github.com/go-openapi/jsonreference v0.20.2

**Copyright notice :** Copyright 2013 sigu-399 https://github.com/sigu-399
Copyright (c) 2004, 2006 The Linux Foundation and its contributors

**License :** Apache License V2.0

Please see above.

**Software :** github.com/go-openapi/swag v0.23.0

**Copyright notice :** Copyright 2015 go-swagger
Copyright (c) 2004, 2006 The Linux Foundation and its contributors

**License :** Apache License V2.0

Please see above.

**Software :** github.com/golang/glog v1.1.0

**Copyright notice :** Copyright 2020 gRPC authors.

**License :** Apache License V2.0

Please see above.

**Software :** github.com/google/btree v1.1.3

**Copyright notice :** Copyright 2014 Google Inc.
Copyright 2014-2022 Google Inc.
(c) OnWriteContext T

**License :** Apache License V2.0

Please see above.

**Software :** github.com/google/gnostic-models v0.7.0

**Copyright notice :** Copyright 2016 Google LLC.
Copyright 2017-2025, Google LLC.
Copyright 2017 Google LLC.
Copyright 2020 Google LLC.
Copyright 2019 Google LLC.
Copyright 2022 Google LLC.
Copyright 2015 Google LLC
Copyright 2008 Google Inc.

**License :** Apache License V2.0

Please see above.

**Software :** github.com/google/go-cmp v0.7.0

**Copyright notice :** Copyright (c) 2017 The Go Authors
Copyright 2017, The Go Authors
Copyright 2019, The Go Authors
Copyright 2020, The Go Authors
Copyright 2018, The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** github.com/google/pprof v0.0.0-20250403155104-27863c87afa6

**Copyright notice :** Copyright 2014 Google Inc.
Copyright 2017 Google Inc.
Copyright (c) 2020 Free Software Foundation
Copyright 2019 Google Inc.
Copyright 2018 Google Inc.
Copyright 2022 Google Inc.
Copyright 2016 Google Inc.
Copyright 2009-2017 Andrea Leofreddi <a.leofreddi@vleo.net>
Copyright 2009-2019 Andrea Leofreddi <a.leofreddi@vleo.net>

**License :** Apache License V2.0

Please see above.

**Software :** github.com/google/uuid v1.6.0

**Copyright notice :** Copyright 2016 Google Inc.
Copyright (c) 2009,2014 Google Inc.
Copyright 2017 Google Inc.
Copyright 2021 Google Inc.
Copyright 2018 Google Inc.
Copyright 2023 Google Inc.

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** github.com/gorilla/websocket v1.5.4-0.20250319132907-e064f32e3674

**Copyright notice :** Copyright 2013 The Gorilla WebSocket Authors
Copyright 2025 The Gorilla WebSocket Authors
Copyright 2014 The Gorilla WebSocket Authors
Copyright 2017 The Gorilla WebSocket Authors
Copyright 2015 The Gorilla WebSocket Authors
Copyright 2019 The Gorilla WebSocket Authors
Copyright (c) 2013 The Gorilla WebSocket Authors
Copyright 2016 The Gorilla WebSocket Authors
Copyright (c) 2008-2009 Bjoern Hoehrmann <bjoern@hoehrmann.de>

**License :** BSD 2-Clause "Simplified" License

Copyright (c) <year> <owner>.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

**Software :** github.com/gregjones/httpcache v0.0.0-20190611155906-901d90724c79

**Copyright notice :** Copyright (c) 2012 Greg Jones (greg.jones@gmail.com)

**License :** MIT License

Please see above.

**Software :** github.com/hashicorp/golang-lru/v2 v2.0.7

**Copyright notice :** Copyright (c) HashiCorp, Inc.,Copyright (c) 2014 HashiCorp, Inc.,Copyright 2009 The Go Authors,Copyright (c) 2009 The Go Authors

**License :** Mozilla Public License 2.0

Mozilla Public License Version 2.0

1. Definitions

     1.1. "Contributor" means each individual or legal entity that creates, contributes to the creation of, or owns Covered Software.  
     1.2. "Contributor Version" means the combination of the Contributions of others (if any) used by a Contributor and that particular Contributor's Contribution.  
     1.3. "Contribution" means Covered Software of a particular Contributor.  
     1.4. "Covered Software" means Source Code Form to which the initial Contributor has attached the notice in Exhibit A, the Executable Form of such Source Code Form, and Modifications of such Source Code Form, in each case including portions thereof.  
     1.5. "Incompatible With Secondary Licenses" means 
      
       (a) that the initial Contributor has attached the notice described in Exhibit B to the Covered Software; or  
       (b) that the Covered Software was made available under the terms of version 1.1 or earlier of the License, but not also under the terms of a Secondary License.  
       
     1.6. "Executable Form" means any form of the work other than Source Code Form.  
     1.7. "Larger Work" means a work that combines Covered Software with other material, in a separate file or files, that is not Covered Software.  
     1.8. "License" means this document.  
     1.9. "Licensable" means having the right to grant, to the maximum extent possible, whether at the time of the initial grant or subsequently, any and all of the rights conveyed by this License.  
     1.10. "Modifications" means any of the following: 
      
       (a) any file in Source Code Form that results from an addition to, deletion from, or modification of the contents of Covered Software; or  
       (b) any new file in Source Code Form that contains any Covered Software.  
       
     1.11. "Patent Claims" of a Contributor means any patent claim(s), including without limitation, method, process, and apparatus claims, in any patent Licensable by such Contributor that would be infringed, but for the grant of the License, by the making, using, selling, offering for sale, having made, import, or transfer of either its Contributions or its Contributor Version.  
     1.12. "Secondary License" means either the GNU General Public License, Version 2.0, the GNU Lesser General Public License, Version 2.1, the GNU Affero General Public License, Version 3.0, or any later versions of those licenses.  
     1.13. "Source Code Form" means the form of the work preferred for making modifications.  
     1.14. "You" (or "Your") means an individual or a legal entity exercising rights under this License. For legal entities, "You" includes any entity that controls, is controlled by, or is under common control with You. For purposes of this definition, "control" means (a) the power, direct or indirect, to cause the direction or management of such entity, whether by contract or otherwise, or (b) ownership of more than fifty percent (50%) of the outstanding shares or beneficial ownership of such entity.  

2. License Grants and Conditions

     2.1. Grants Each Contributor hereby grants You a world-wide, royalty-free, non-exclusive license:  
      
       (a) under intellectual property rights (other than patent or trademark) Licensable by such Contributor to use, reproduce, make available, modify, display, perform, distribute, and otherwise exploit its Contributions, either on an unmodified basis, with Modifications, or as part of a Larger Work; and  
       (b) under Patent Claims of such Contributor to make, use, sell, offer for sale, have made, import, and otherwise transfer either its Contributions or its Contributor Version.  
       
     2.2. Effective Date The licenses granted in Section 2.1 with respect to any Contribution become effective for each Contribution on the date the Contributor first distributes such Contribution.   
     2.3. Limitations on Grant Scope The licenses granted in this Section 2 are the only rights granted under this License. No additional rights or licenses will be implied from the distribution or licensing of Covered Software under this License. Notwithstanding Section 2.1(b) above, no patent license is granted by a Contributor:  
      
       (a) for any code that a Contributor has removed from Covered Software; or  
       (b) for infringements caused by: (i) Your and any other third party's modifications of Covered Software, or (ii) the combination of its Contributions with other software (except as part of its Contributor Version); or  
       (c) under Patent Claims infringed by Covered Software in the absence of its Contributions.  
      This License does not grant any rights in the trademarks, service marks, or logos of any Contributor (except as may be necessary to comply with the notice requirements in Section 3.4).  
     2.4. Subsequent Licenses No Contributor makes additional grants as a result of Your choice to distribute the Covered Software under a subsequent version of this License (see Section 10.2) or under the terms of a Secondary License (if permitted under the terms of Section 3.3).  
     2.5. Representation Each Contributor represents that the Contributor believes its Contributions are its original creation(s) or it has sufficient rights to grant the rights to its Contributions conveyed by this License.   
     2.6. Fair Use This License is not intended to limit any rights You have under applicable copyright doctrines of fair use, fair dealing, or other equivalents.   
     2.7. Conditions Sections 3.1, 3.2, 3.3, and 3.4 are conditions of the licenses granted in Section 2.1.  

3. Responsibilities

     3.1. Distribution of Source Form All distribution of Covered Software in Source Code Form, including any Modifications that You create or to which You contribute, must be under the terms of this License. You must inform recipients that the Source Code Form of the Covered Software is governed by the terms of this License, and how they can obtain a copy of this License. You may not attempt to alter or restrict the recipients' rights in the Source Code Form.   
     3.2. Distribution of Executable Form If You distribute Covered Software in Executable Form then: 
      
       (a) such Covered Software must also be made available in Source Code Form, as described in Section 3.1, and You must inform recipients of the Executable Form how they can obtain a copy of such Source Code Form by reasonable means in a timely manner, at a charge no more than the cost of distribution to the recipient; and  
       (b) You may distribute such Executable Form under the terms of this License, or sublicense it under different terms, provided that the license for the Executable Form does not attempt to limit or alter the recipients' rights in the Source Code Form under this License.  
       
     3.3. Distribution of a Larger Work You may create and distribute a Larger Work under terms of Your choice, provided that You also comply with the requirements of this License for the Covered Software. If the Larger Work is a combination of Covered Software with a work governed by one or more Secondary Licenses, and the Covered Software is not Incompatible With Secondary Licenses, this License permits You to additionally distribute such Covered Software under the terms of such Secondary License(s), so that the recipient of the Larger Work may, at their option, further distribute the Covered Software under the terms of either this License or such Secondary License(s).   
     3.4. Notices You may not remove or alter the substance of any license notices (including copyright notices, patent notices, disclaimers of warranty, or limitations of liability) contained within the Source Code Form of the Covered Software, except that You may alter any license notices to the extent required to remedy known factual inaccuracies.   
     3.5. Application of Additional Terms You may choose to offer, and to charge a fee for, warranty, support, indemnity or liability obligations to one or more recipients of Covered Software. However, You may do so only on Your own behalf, and not on behalf of any Contributor. You must make it absolutely clear that any such warranty, support, indemnity, or liability obligation is offered by You alone, and You hereby agree to indemnify every Contributor for any liability incurred by such Contributor as a result of warranty, support, indemnity or liability terms You offer. You may include additional disclaimers of warranty and limitations of liability specific to any jurisdiction.   

4. Inability to Comply Due to Statute or Regulation If it is impossible for You to comply with any of the terms of this License with respect to some or all of the Covered Software due to statute, judicial order, or regulation then You must: (a) comply with the terms of this License to the maximum extent possible; and (b) describe the limitations and the code they affect. Such description must be placed in a text file included with all distributions of the Covered Software under this License. Except to the extent prohibited by statute or regulation, such description must be sufficiently detailed for a recipient of ordinary skill to be able to understand it.
5. Termination

     5.1. The rights granted under this License will terminate automatically if You fail to comply with any of its terms. However, if You become compliant, then the rights granted under this License from a particular Contributor are reinstated (a) provisionally, unless and until such Contributor explicitly and finally terminates Your grants, and (b) on an ongoing basis, if such Contributor fails to notify You of the non-compliance by some reasonable means prior to 60 days after You have come back into compliance. Moreover, Your grants from a particular Contributor are reinstated on an ongoing basis if such Contributor notifies You of the non-compliance by some reasonable means, this is the first time You have received notice of non-compliance with this License from such Contributor, and You become compliant prior to 30 days after Your receipt of the notice.  
     5.2. If You initiate litigation against any entity by asserting a patent infringement claim (excluding declaratory judgment actions, counter-claims, and cross-claims) alleging that a Contributor Version directly or indirectly infringes any patent, then the rights granted to You by any and all Contributors for the Covered Software under Section 2.1 of this License shall terminate.  
     5.3. In the event of termination under Sections 5.1 or 5.2 above, all end user license agreements (excluding distributors and resellers) which have been validly granted by You or Your distributors under this License prior to termination shall survive termination.  

6. Disclaimer of Warranty Covered Software is provided under this License on an "as is" basis, without warranty of any kind, either expressed, implied, or statutory, including, without limitation, warranties that the Covered Software is free of defects, merchantable, fit for a particular purpose or non-infringing. The entire risk as to the quality and performance of the Covered Software is with You. Should any Covered Software prove defective in any respect, You (not any Contributor) assume the cost of any necessary servicing, repair, or correction. This disclaimer of warranty constitutes an essential part of this License. No use of any Covered Software is authorized under this License except under this disclaimer.
7. Limitation of Liability Under no circumstances and under no legal theory, whether tort (including negligence), contract, or otherwise, shall any Contributor, or anyone who distributes Covered Software as permitted above, be liable to You for any direct, indirect, special, incidental, or consequential damages of any character including, without limitation, damages for lost profits, loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages or losses, even if such party shall have been informed of the possibility of such damages. This limitation of liability shall not apply to liability for death or personal injury resulting from such party's negligence to the extent applicable law prohibits such limitation. Some jurisdictions do not allow the exclusion or limitation of incidental or consequential damages, so this exclusion and limitation may not apply to You.
8. Litigation Any litigation relating to this License may be brought only in the courts of a jurisdiction where the defendant maintains its principal place of business and such litigation shall be governed by laws of that jurisdiction, without reference to its conflict-of-law provisions. Nothing in this Section shall prevent a party's ability to bring cross-claims or counter-claims.
9. Miscellaneous This License represents the complete agreement concerning the subject matter hereof. If any provision of this License is held to be unenforceable, such provision shall be reformed only to the extent necessary to make it enforceable. Any law or regulation which provides that the language of a contract shall be construed against the drafter shall not be used to construe this License against a Contributor.
10. Versions of the License

     10.1. New Versions Mozilla Foundation is the license steward. Except as provided in Section 10.3, no one other than the license steward has the right to modify or publish new versions of this License. Each version will be given a distinguishing version number.   
     10.2. Effect of New Versions You may distribute the Covered Software under the terms of the version of the License under which You originally received the Covered Software, or under the terms of any subsequent version published by the license steward.   
     10.3. Modified Versions If you create software not governed by this License, and you want to create a new license for such software, you may create and use a modified version of this License if you rename the license and remove any references to the name of the license steward (except to note that such modified license differs from this License).   
     10.4. Distributing Source Code Form that is Incompatible With Secondary Licenses If You choose to distribute Source Code Form that is Incompatible With Secondary Licenses under the terms of this version of the License, the notice described in Exhibit B of this License must be attached.  

Exhibit A - Source Code Form License Notice
This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
If it is not possible or desirable to put the notice in a particular file, then You may include the notice in a location (such as a LICENSE file in a relevant directory) where a recipient would be likely to look for such a notice.
You may add additional accurate notices of copyright ownership.
Exhibit B - "Incompatible With Secondary Licenses" Notice
This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.

**Software :** github.com/hinshun/vt10x v0.0.0-20220119200601-820417d04eec

**Copyright notice :** Copyright (c) 2013 James Gray

**License :** MIT License

Please see above.

**Software :** github.com/hpcloud/tail v1.0.0

**Copyright notice :** Copyright (c) 2015 HPE Software Inc.
Copyright (c) 2013 ActiveState Software Inc.
(c) Copyright 2015 Hewlett Packard Enterprise Development LP
Copyright (c) 2014 ActiveState
Copyright (c) 2013

**License :** MIT License

Please see above.

**Software :** github.com/inconshreveable/mousetrap v1.1.0

**Copyright notice :** Copyright 2022 Alan Shreve

**License :** Apache License V2.0

Please see above.

**Software :** github.com/jmespath/go-jmespath v0.4.1-0.20220621161143-b0104c826a24

**Copyright notice :** No copyright info provided

**License :** Apache License V2.0

Please see above.

**Software :** github.com/jmespath/go-jmespath/internal/testify v1.5.1

**Copyright notice :** Copyright (c) 2012-2018 Mat Ryer and Tyler Bunnell

**License :** MIT License

Please see above.

**Software :** github.com/josharian/intern v1.0.0

**Copyright notice :** Copyright (c) 2019 Josh Bleecher Snyder

**License :** MIT License

Please see above.

**Software :** github.com/json-iterator/go v1.1.12

**Copyright notice :** Copyright (c) 2016 json-iterator

**License :** MIT License

Please see above.

**Software :** github.com/kballard/go-shellquote v0.0.0-20180428030007-95032a82bc51

**Copyright notice :** Copyright (C) 2014 Kevin Ballard

**License :** MIT License

Please see above.

**Software :** github.com/kr/pretty v0.3.1

**Copyright notice :** Copyright 2012 Keith Rarick

**License :** MIT License

Please see above.

**Software :** github.com/kr/text v0.2.0

**Copyright notice :** Copyright 2012 Keith Rarick

**License :** MIT License

Please see above.

**Software :** github.com/lib/pq v1.10.9

**Copyright notice :** Copyright (c) 2011-2013, pq Contributors
Portions Copyright (c) 2011 Blake Mizerany
Copyright (c) 2014 - Gustavo Niemeyer <gustavo@niemeyer.net>

**License :** MIT License

Please see above.

**Software :** github.com/mailru/easyjson v0.7.7

**Copyright notice :** Copyright (c) 2009 The Go Authors

**License :** MIT License

Please see above.

**Software :** github.com/mitchellh/mapstructure v1.5.1-0.20220423185008-bf980b35cac4

**Copyright notice :** Copyright (c) 2013 Mitchell Hashimoto

**License :** MIT License

Please see above.

**Software :** github.com/moby/spdystream v0.5.0

**Copyright notice :** Copyright 2014-2021 Docker Inc.
Copyright 2013-2021 Docker, inc.
Copyright 2013 The Go Authors
Copyright 2011 The Go Authors

**License :** Apache License V2.0

Please see above.

**Software :** github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd

**Copyright notice :** No copyright notice found in source files of this software.

**License :** Apache License V2.0

Please see above.

**Software :** github.com/modern-go/reflect2 v1.0.3-0.20250322232337-35a7c28c31ee

**Copyright notice :** No copyright info provided

**License :** Apache License V2.0

Please see above.

**Software :** github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822

**Copyright notice :** Copyright (c) 2011, Open Knowledge Foundation Ltd.

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** github.com/mxk/go-flowrate v0.0.0-20140419014527-cca7078d478f

**Copyright notice :** Copyright (c) 2014 The Go-FlowRate Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** github.com/onsi/ginkgo v1.12.0

**Copyright notice :** Copyright (c) 2013-2014 Onsi Fakhouri
Copyright (c) 2016 Yasuhiro Matsumoto
Copyright (c) Yasuhiro MATSUMOTO <mattn.jp@gmail.com>

**License :** MIT License

Please see above.

**Software :** github.com/onsi/ginkgo/v2 v2.27.2

**Copyright notice :** No copyright info provided

**License :** MIT License

Please see above.

**Software :** github.com/onsi/gomega v1.38.2

**Copyright notice :** Copyright (c) 2013-2014 Onsi Fakhouri Copyright (c) 2014 Amit Kumar Gupta

**License :** MIT License

Please see above.

**Software :** github.com/peterbourgon/diskv v2.0.1+incompatible

**Copyright notice :** Copyright (c) 2011-2012 Peter Bourgon

**License :** MIT License

Please see above.

**Software :** github.com/pkg/sftp v1.13.6

**Copyright notice :** Copyright (c) 2013, Dave Cheney

**License :** BSD 2-Clause "Simplified" License

Please see above.

**Software :** github.com/pmezard/go-difflib v1.0.0

**Copyright notice :** Copyright (c) 2013, Patrick Mezard

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** github.com/prometheus/client_golang v1.20.5

**Copyright notice :** "Copyright 2018 The Prometheus Authors
Copyright 2012-2015 The Prometheus Authors
Copyright 2013-2015 Blake Mizerany, Bjorn Rabenstein
Copyright 2010 The Go Authors
Copyright 2015 The Prometheus Authors
Copyright 2017 The Prometheus Authors
Copyright 2019 The Prometheus Authors
Copyright 2024 The Prometheus Authors
Copyright 2022 The Prometheus Authors
Copyright (c) 2013 The Go Authors
Copyright 2013 The Go Authors
Copyright 2014 The Prometheus Authors
Copyright 2021 The Prometheus Authors
Copyright 2016 The Prometheus Authors
Copyright 2020 The Prometheus Authors
Copyright 2023 The Prometheus Authors
Copyright (c) 2013, The Prometheus Authors
Copyright (c) 2015 Bjorn Rabenstein"

**License :** Apache License V2.0

Please see above.

**Software :** github.com/rogpeppe/go-internal v1.14.1

**Copyright notice :** Copyright (c) 2018 The Go Authors
Copyright 2017 The Go Authors
Copyright 2018 The Go Authors
Copyright 2022 The Go Authors
Copyright 2015 The Go Authors
Copyright 2012 The Go Authors
Copyright 2011 The Go Authors
Copyright 2010 The Go Authors
Copyright 2016 The Go Authors
Copyright 2014 The Go Authors
Copyright 2019 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** github.com/russross/blackfriday/v2 v2.1.0

**Copyright notice :** Copyright (c) 2011 Russ Ross <russ@russross.com>
Copyright (c) 2011 Russ Ross
(c) 2004 Foo Corporation

**License :** BSD 2-Clause "Simplified" License

Please see above.

**Software :** github.com/sirupsen/logrus v1.9.4

**Copyright notice :** No copyright info provided

**License :** MIT License

Please see above.

**Software :** github.com/spf13/cobra v1.10.2

**Copyright notice :** Copyright 2013-2023 The Cobra Authors

**License :** Apache License V2.0

Please see above.

**Software :** github.com/stretchr/objx v0.5.2

**Copyright notice :** Copyright (c) 2014 Stretchr, Inc.
Copyright (c) 2017-2018 objx contributors

**License :** MIT License

Please see above.

**Software :** github.com/stretchr/testify v1.11.1

**Copyright notice :** Copyright (c) 2012-2020 Mat Ryer, Tyler Bunnell and contributors

**License :** MIT License

Please see above.

**Software :** github.com/vmware/govmomi v0.29.0

**Copyright notice :** Copyright (c) 2014-2016 VMware, Inc.
Copyright (c) 2014-2015 VMware, Inc.
Copyright (c) 2021 VMware, Inc.
Copyright (c) 2019 VMware, Inc.
Copyright (c) 2015 VMware, Inc.
Copyright (c) 2016-2017 VMware, Inc.
Copyright (c) 2017 VMware, Inc.
Copyright (c) 2014-2022 VMware, Inc.
Copyright (c) 2015-2017 VMware, Inc.
Copyright (c) 2020 VMware, Inc.
Copyright (c) 2014-2017 VMware, Inc.
Copyright (c) 2014-2020 VMware, Inc.
Copyright (c) 2014 VMware, Inc.
Copyright (c) 2014-2021 VMware, Inc.
Copyright (c) ENV
Copyright (c) 2016 VMware, Inc.
Copyright (c) 2022 VMware, Inc.
Copyright (c) 2014-2018 VMware, Inc.
Copyright (c) 2015-2016 VMware, Inc.
Copyright (c) 2018 VMware, Inc.
Copyright (c) 2017-2018 VMware, Inc.
Copyright (c) 2015-2019 VMware, Inc.
Copyright (c) 2015-2021 VMware, Inc.
Copyright (c) YEARS VMware, Inc.
Copyright 2017 VMware, Inc.
Copyright 2017-2018 VMware, Inc.
Copyright (c) 2015-2020 VMware, Inc.
Copyright (c) 2017-2021 VMware, Inc.
Copyright 2016-2017 VMware, Inc.
Copyright (c) 2018-2022 VMware, Inc.
Copyright (c) 2015-2022 VMware, Inc.
Copyright 2011 The Go Authors
Copyright (c) 2009 The Go Authors
Copyright 2009 The Go Authors

**License :** Apache License V2.0

Please see above.

**Software :** github.com/x448/float16 v0.8.4

**Copyright notice :** Copyright 2019 Montgomery Edwards⁴⁴⁸ and Faye Amacker

**License :** MIT License

Please see above.

**Software :** go.uber.org/goleak v1.3.0

**Copyright notice :** Copyright (c) 2018 Uber Technologies, Inc.
Copyright (c) 2017 Uber Technologies, Inc.
Copyright (c) 2021 Uber Technologies, Inc.
Copyright (c) 2017-2023 Uber Technologies, Inc

**License :** MIT License

Please see above.

**Software :** go.uber.org/mock v0.4.0

**Copyright notice :** Copyright 2010 Google LLC.
Copyright 2010 Google Inc.
Copyright 2020 Google Inc.
Copyright 2011 Google Inc.
Copyright 2022 Google LLC
Copyright 2012 Google Inc.
Copyright 2020 Google LLC

**License :** Apache License V2.0

Please see above.

**Software :** go.uber.org/zap v1.27.0

**Copyright notice :** Copyright (c) 2016 Uber Technologies, Inc.
Copyright (c) Uber Technologies, Inc.
Copyright (c) 2020 Uber Technologies, Inc.
Copyright (c) 2017 Uber Technologies, Inc.
Copyright (c) 2021 Uber Technologies, Inc.
Copyright (c) 2016-2017 Uber Technologies, Inc.
Copyright (c) 2016-2022 Uber Technologies, Inc.
Copyright (c) 2022 Uber Technologies, Inc.
Copyright (c) 2016, 2017 Uber Technologies, Inc.
Copyright (c) 2023 Uber Technologies, Inc.
Copyright (c) 2018 Uber Technologies, Inc.

**License :** MIT License

Please see above.

**Software :** go.yaml.in/yaml/v2 v2.4.3

**Copyright notice :** Copyright (c) 2006 Kirill Simonov
Copyright 2011-2016 Canonical Ltd.

**License :** Apache License V2.0

Please see above.

**Software :** go.yaml.in/yaml/v3 v3.0.4

**Copyright notice :** Copyright (c) 2011-2019 Canonical Ltd
Copyright (c) 2006-2010 Kirill Simonov
Copyright (c) 2006-2011 Kirill Simonov
Copyright 2011-2016 Canonical Ltd.

**License :** Apache License V2.0

Please see above.

**Software :** go.yaml.in/yaml/v3 v3.0.4

**Copyright notice :** Copyright (c) 2011-2019 Canonical Ltd
Copyright (c) 2006-2010 Kirill Simonov
Copyright (c) 2006-2011 Kirill Simonov
Copyright 2011-2016 Canonical Ltd.

**License :** MIT License

Please see above.

**Software :** golang.org/x/crypto v0.50.0

**Copyright notice :** Copyright 2009 The Go Authors
Copyright 2015 The Go Authors
Copyright 2018 The Go Authors
Copyright 2025 The Go Authors
Copyright 2019 The Go Authors
Copyright 2016 The Go Authors
Copyright 2017 The Go Authors
Copyright 2011 The Go Authors
Copyright 2010 The Go Authors
Copyright 2012 The Go Authors
Copyright 2014 The Go Authors
Copyright 2023 The Go Authors
Copyright 2021 The Go Authors
Copyright 2020 The Go Authors
Copyright 2022 The Go Authors
Copyright 2013 The Go Authors
Copyright 2024 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** golang.org/x/net v0.52.0

**Copyright notice :** Copyright 2009 The Go Authors
Copyright 2016 The Go Authors
Copyright 2017 The Go Authors
Copyright 2014 The Go Authors
Copyright 2015 The Go Authors
Copyright 2010 The Go Authors
Copyright 2025 The Go Authors
Copyright 2023 The Go Authors
Copyright 2011 The Go Authors
Copyright 2013 The Go Authors
Copyright 2012 The Go Authors
Copyright 2024 The Go Authors
Copyright (c) 2009 Apple Inc.
Copyright 2018 The Go Authors
Copyright 2021 The Go Authors
Copyright 2026 The Go Authors
(c) cc.fr
Copyright 2022 The Go Authors
Copyright 2020 The Go Authors
Copyright 2019 The Go Authors
(c) if err p.JoinGroup en0, &net.UDPAddr IP group

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** golang.org/x/oauth2 v0.30.0

**Copyright notice :** Copyright 2014 The Go Authors
Copyright 2009 The Go Authors
Copyright 2023 The Go Authors
Copyright 2017 The oauth2 Authors
Copyright 2021 The Go Authors
Copyright 2015 The oauth2 Authors
Copyright 2018 The Go Authors
Copyright 2019 The Go Authors
Copyright 2015 The Go Authors
Copyright 2016 The Go Authors
Copyright 2022 The Go Authors
Copyright 2020 The Go Authors
Copyright 2024 The Go Authors
Copyright 2017 The Go Authors
Copyright 2018 The oauth2 Authors

**License :** The Go license

**Software :** golang.org/x/sync v0.20.0

**Copyright notice :** Copyright 2009 The Go Authors
Copyright 2016 The Go Authors
Copyright 2017 The Go Authors
Copyright 2013 The Go Authors
Copyright 2019 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** golang.org/x/sys v0.43.0

**Copyright notice :** No copyright info provided

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** golang.org/x/term v0.42.0

**Copyright notice :** No copyright info provided

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** golang.org/x/time v0.9.0

**Copyright notice :** Copyright 2009 The Go Authors
Copyright 2015 The Go Authors
Copyright 2022 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** golang.org/x/tools/go/packages/packagestest v0.1.1-deprecated

**Copyright notice :** No copyright info provided

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** google.golang.org/protobuf v1.36.8

**Copyright notice :** Copyright 2019 The Go Authors
Copyright d d d d The Go Authors
Copyright d d d d Google Inc
Copyright (c) 2018 The Go Authors
Copyright 2018 The Go Authors
Copyright 2024 The Go Authors
Copyright 2020 The Go Authors
Copyright 2022 The Go Authors
Copyright 2025 The Go Authors
Copyright 2008 Google Inc.
Copyright 2024 Google Inc.
Copyright 2021 The Go Authors
Copyright 2023 The Go Authors
Copyright 2023 Google Inc.

**License :** Lawrence Berkeley National Labs BSD variant license

Copyright (c) 2003, The Regents of the University of California, through Lawrence Berkeley National Laboratory (subject to receipt of any required approvals from the U.S. Dept. of Energy). All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

(1) Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.  
(2) Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.  
(3)  Neither the name of the University of California, Lawrence Berkeley National Laboratory, U.S. Dept. of Energy nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER, THE UNITED STATES GOVERNMENT, OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
You are under no obligation whatsoever to provide any bug fixes, patches, or upgrades to the features, functionality or performance of the source code ("Enhancements") to anyone; however, if you choose to make your Enhancements available either publicly, or directly to Lawrence Berkeley National Laboratory, without imposing a separate written license agreement for such Enhancements, then you hereby grant the following license: a non-exclusive, royalty-free perpetual license to install, use, modify, prepare derivative works, incorporate into other computer software, distribute, and sublicense such Enhancements or derivative works thereof, in binary and source code form.

**Software :** gopkg.in/check.v1 v1.0.0-20201130134442-10cb98267c6c

**Copyright notice :** Gocheck - A rich testing framework for Go   Copyright (c) 2010-2013 Gustavo Niemeyer <gustavo@niemeyer.net>  All rights reserved.  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:   1. Redistributions of source code must retain the above copyright notice, this    list of conditions and the following disclaimer.  2. Redistributions in binary form must reproduce the above copyright notice,    this list of conditions and the following disclaimer in the documentation    and/or other materials provided with the distribution.   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

**License :** BSD 2-Clause "Simplified" License

Please see above.

**Software :** gopkg.in/evanphx/json-patch.v4 v4.13.0

**Copyright notice :** Copyright (c) 2014, Evan Phoenix

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** gopkg.in/inf.v0 v0.9.1

**Copyright notice :** Copyright (c) 2012 Peter Suranyi
Portions Copyright (c) 2009 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** gopkg.in/natefinch/lumberjack.v2 v2.2.1

**Copyright notice :** Copyright (c) 2014 Nate Finch

**License :** MIT License

Please see above.

**Software :** gopkg.in/yaml.v3 v3.0.1

**Copyright notice :** Copyright (c) 2011-2019 Canonical Ltd
Copyright (c) 2006-2010 Kirill Simonov
Copyright (c) 2006-2011 Kirill Simonov
Copyright 2011-2016 Canonical Ltd.

**License :** MIT License

Please see above.

**Software :** gopkg.in/yaml.v3 v3.0.1

**Copyright notice :** Copyright (c) 2011-2019 Canonical Ltd
Copyright (c) 2006-2010 Kirill Simonov
Copyright (c) 2006-2011 Kirill Simonov
Copyright 2011-2016 Canonical Ltd.

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/api v0.35.3

**Copyright notice :** No copyright info provided

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/apimachinery v0.35.3

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors
Copyright 2017 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2022 The Kubernetes Authors
Copyright 2024 The Kubernetes Authors
Copyright 2014 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright 2015 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2016 The Kubernetes Authors
Copyright 2018 The Kubernetes Authors
Copyright (c) 2009 The Go Authors
Copyright 2013 The Go Authors
Copyright 2009 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** k8s.io/apimachinery v0.35.3

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors
Copyright 2017 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2022 The Kubernetes Authors
Copyright 2024 The Kubernetes Authors
Copyright 2014 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright 2015 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2016 The Kubernetes Authors
Copyright 2018 The Kubernetes Authors
Copyright (c) 2009 The Go Authors
Copyright 2013 The Go Authors
Copyright 2009 The Go Authors

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/client-go v0.35.3

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors
Copyright 2022 The Kubernetes Authors
Copyright 2015 The Kubernetes Authors
Copyright 2014 The Kubernetes Authors
Copyright 2018 The Kubernetes Authors
Copyright 2016 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2017 The Kubernetes Authors
Copyright 2024 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright (c) 2009 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** k8s.io/client-go v0.35.3

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors
Copyright 2022 The Kubernetes Authors
Copyright 2015 The Kubernetes Authors
Copyright 2014 The Kubernetes Authors
Copyright 2018 The Kubernetes Authors
Copyright 2016 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2017 The Kubernetes Authors
Copyright 2024 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright (c) 2009 The Go Authors

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/code-generator v0.28.3

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright 2017 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2015 The Kubernetes Authors
Copyright 2016 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright 2018 The Kubernetes Authors
Copyright (c) 2009 The Go Authors

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/gengo/v2 v2.0.0-20250604051438-85fd79dbfd9f

**Copyright notice :** Copyright 2015 The Kubernetes Authors
Copyright 2014 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2024 The Kubernetes Authors
Copyright 2021 The Kubernetes Authors

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/klog/v2 v2.130.1

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright 2022 The Kubernetes Authors
Copyright 2013 Google Inc.
Copyright 2023 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright 2014 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2020 Intel Corporation

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/kube-openapi v0.0.0-20250910181357-589584f1c912

**Copyright notice :** Copyright 2018 The Kubernetes Authors
Copyright 2024 The Kubernetes Authors
Copyright 2017 The Kubernetes Authors
Copyright 2016 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2021 The Kubernetes Authors
Copyright 2022 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright 2020 The Go Authors
Copyright 2022 The Go Authors
Copyright 2021 The Go Authors
Copyright (c) 2020 The Go Authors
Copyright (c) 2014 Alex Saskevich
Copyright 2019 The Kubernetes Authors
Copyright 2015 go-swagger
Copyright (c) 2004, 2006 The Linux Foundation and its contributors
Copyright 2017 go-swagger
Copyright 2024 go-swagger
Copyright (c) MongoDB, Inc. 2017-present

**License :** Apache License V2.0

Please see above.

**Software :** k8s.io/utils v0.0.0-20251002143259-bc988d571ff4

**Copyright notice :** No copyright info provided

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** k8s.io/utils v0.0.0-20251002143259-bc988d571ff4

**Copyright notice :** No copyright info provided

**License :** Apache License V2.0

Please see above.

**Software :** sigs.k8s.io/controller-runtime v0.16.3

**Copyright notice :** Copyright 2018 The Kubernetes Authors<br/>Copyright 2020 The Kubernetes Authors<br/>Copyright 2019 The Kubernetes Authors<br/>Copyright 2018 The Kubernetes authors<br/>Copyright 2021 The Kubernetes Authors<br/>Copyright 2023 The Kubernetes Authors<br/>Copyright 2022 The Kubernetes Authors<br/>Copyright 2017 The Kubernetes Authors<br/>Copyright 2016 The Kubernetes Authors<br/>Copyright 2014 The Kubernetes Authors

**License :** Apache License V2.0

Please see above.

**Software :** sigs.k8s.io/json v0.0.0-20250730193827-2d320260d730

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright (c) 2009 The Go Authors
Copyright 2011 The Go Authors
Copyright 2010 The Go Authors
Copyright 2016 The Go Authors
Copyright 2018 The Go Authors
Copyright 2013 The Go Authors
Copyright 2019 The Go Authors
Copyright 2021 The Go Authors

**License :** Apache License V2.0

Please see above.

**Software :** sigs.k8s.io/json v0.0.0-20250730193827-2d320260d730

**Copyright notice :** Copyright 2021 The Kubernetes Authors
Copyright (c) 2009 The Go Authors
Copyright 2011 The Go Authors
Copyright 2010 The Go Authors
Copyright 2016 The Go Authors
Copyright 2018 The Go Authors
Copyright 2013 The Go Authors
Copyright 2019 The Go Authors
Copyright 2021 The Go Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** sigs.k8s.io/randfill v1.0.0

**Copyright notice :** Copyright 2014 Google Inc.
Copyright 2014 The gofuzz
Copyright 2025 The Kubernetes Authors

**License :** Apache License V2.0

Please see above.

**Software :** sigs.k8s.io/structured-merge-diff/v6 v6.3.0

**Copyright notice :** Copyright 2018 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors
Copyright 2019 The Kubernetes Authors
Copyright 2024 The Kubernetes Authors
Copyright 2020 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors

**License :** Apache License V2.0

Please see above.

**Software :** sigs.k8s.io/yaml v1.6.0

**Copyright notice :** Copyright 2022 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2013 The Go Authors
Copyright (c) 2014 Sam Ghods
Copyright (c) 2012 The Go Authors
Copyright (c) 2006-2010 Kirill Simonov
Copyright (c) 2006-2011 Kirill Simonov
Copyright (c) 2011-2019 Canonical Ltd
Copyright 2021 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors

**License :** Apache License V2.0

Please see above.

**Software :** sigs.k8s.io/yaml v1.6.0

**Copyright notice :** Copyright 2022 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2013 The Go Authors
Copyright (c) 2014 Sam Ghods
Copyright (c) 2012 The Go Authors
Copyright (c) 2006-2010 Kirill Simonov
Copyright (c) 2006-2011 Kirill Simonov
Copyright (c) 2011-2019 Canonical Ltd
Copyright 2021 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors

**License :** BSD 3-Clause "New" or "Revised" License

Please see above.

**Software :** sigs.k8s.io/yaml v1.6.0

**Copyright notice :** Copyright 2022 The Kubernetes Authors
Copyright 2023 The Kubernetes Authors
Copyright 2013 The Go Authors
Copyright (c) 2014 Sam Ghods
Copyright (c) 2012 The Go Authors
Copyright (c) 2006-2010 Kirill Simonov
Copyright (c) 2006-2011 Kirill Simonov
Copyright (c) 2011-2019 Canonical Ltd
Copyright 2021 The Kubernetes Authors
Copyright 2025 The Kubernetes Authors

**License :** MIT License

Please see above.

### Written Offer
This product contains software whose rights holders license it on the terms of the GNU General Public License, version 2 (GPLv2) and/or other open source software licenses. We will provide you and any third party with the source code of the software licensed under an open source software license if you send us a written request by mail or email to the following addresses:

foss@huawei.com

detailing the name of the product and the firmware version for which you need the source code and indicating how we can contact you.

Please note you need to make a payment before you obtain the complete Corresponding Source Code from us. For how much you will pay and how we will deliver the complete Corresponding Source Code to you, we will further discuss it by mail or email.

This offer is valid to anyone in receipt of this information.

**THIS OFFER IS VALID FOR THREE YEARS FROM THE MOMENT WE DISTRIBUTED THE PRODUCT OR FIRMWARE.**